import java.awt.*;
public class SortingAlgorithms {
        public void bubbleSort(SortArray arr){
            int len=arr.arrSize;
            arr.isSorting = true;
            arr.comparisons = 0;
            for(int i=0;i<len-1;i++){
                for(int j=0;j<len-i-1;j++){
                    if (!arr.isSorting){
                        return;
                    }
                    arr.barColor[j] = arr.blueColor;
                    if (i == 0 && j == 0){
                        arr.Update();
                    }
                    arr.sleep(arr.animSpeed);
                    arr.Update();
                    arr.barColor[j] = Color.white;
                    if(arr.getValue(j)>arr.getValue(j+1)){
                        arr.swap(j, j+1);
                    }
                    arr.Update();
                    arr.increaseComparison();
                }
                arr.barColor[len-i-1] = arr.pinkColor;
            }
            arr.sortAnim();
        }
        public void insertionSort(SortArray arr) {
            int n = arr.arrSize;
            arr.isSorting = true;
            arr.comparisons = 0;
            for (int i = 1; i < n; i++) {
                int temp = arr.getValue(i);
                int j = i;

                arr.barColor[i] = arr.blueColor;
                arr.Update();
                arr.sleep(arr.animSpeed);
                while ((j > 0) && (arr.getValue(j-1) > temp)) {
                    if (!arr.isSorting){
                        return;
                    }
                    arr.barColor[j] = Color.red;
                    arr.barColor[j-1] = Color.red;
                    arr.Update();
                    arr.sleep(arr.animSpeed);
                    arr.setValueatIndex(j, j-1);
                    arr.increaseComparison();
                    arr.barColor[j] = Color.white;
                    arr.barColor[j-1] = Color.white;
                    j--;
                }
                arr.setValue(j, temp);
                arr.barColor[i] = Color.white;
            }
            arr.sortAnim();
        }
        public void selectionSort(SortArray arr){
            arr.isSorting = true;
            arr.comparisons = 0;
            for(int i=0;i<arr.arrSize-1;i++){
                int min=i;
                arr.barColor[i] = arr.purpleColor;

                for(int j=i+1;j<arr.arrSize;j++){
                    if (!arr.isSorting){
                        return;
                    }
                    arr.barColor[j] = arr.blueColor;
                    if (min != i)
                        arr.barColor[min] = arr.orangeColor;
                    arr.Update();

                    if(arr.getValue(j)<arr.getValue(min)){
                        if (min != i)
                            arr.barColor[min] = Color.white;

                        min=j;
                        arr.barColor[min] = arr.orangeColor;
                    }

                    arr.sleep(arr.animSpeed);
                    arr.increaseComparison();
                    arr.barColor[j] = Color.white;
                    arr.Update();
                }
                arr.barColor[i] = Color.white;
                arr.swap(i, min);
                arr.barColor[i] = arr.pinkColor;

            }
            arr.sortAnim();
        }
        public void merge(SortArray arr,int start,int mid,int end){
            int l=mid-start+1;
            int r=end-mid;
            int[] leftarr =new int[l];
            int[] rightarr =new int[r];
            for(int i=0;i<l;i++){
                leftarr[i] = arr.getValue(start+i);
            }
            for(int j=0;j<r;j++){
                rightarr[j] = arr.getValue(mid+j+1);
            }
            int i=0;
            int j=0;
            int k=start;
            while(i<l&&j<r){
                if (k != start && k!= end)
                    arr.barColor[k] = arr.orangeColor;

                if (!arr.isSorting){
                    return;
                }

                if(leftarr[i]<=rightarr[j]){
                    arr.setValue(k, leftarr[i]);
                    i++;
                }
                else{
                    arr.setValue(k, rightarr[j]);
                    j++;
                }
                k++;
                arr.sleep(arr.animSpeed);
                arr.Update();
                arr.increaseComparison();
            }
            while (i<l){
                if (k != start && k!= end)
                    arr.barColor[k] = arr.orangeColor;

                if (!arr.isSorting){
                    return;
                }

                arr.setValue(k, leftarr[i]);
                i++;
                k++;
                arr.Update();
                arr.increaseComparison();
            }
            while (j<r){
                if (k != start && k!= end)
                    arr.barColor[k] = arr.orangeColor;

                if (!arr.isSorting){
                    return;
                }

                arr.setValue(k, rightarr[j]);
                j++;
                k++;

                arr.Update();
                arr.increaseComparison();
            }
        }
        public void mergee(SortArray A, int start, int mid, int end){
            int p = start, q = mid + 1;
            int r = start;
            int s = end;
            int[] Arr = new int[end - start + 1];
            int k = 0;
            if (!A.isSorting){
                return;
            }
            Color startColorA =  A.barColor[start];
            Color startColorB =  A.barColor[end];
            A.barColor[start] = new Color(0, 184, 148);
            A.barColor[end] = new Color(0, 184, 148);

            A.Update();
            A.sleep(A.animSpeed);

            if (!A.isSorting){
                return;
            }
            A.barColor[start] = startColorA;
            A.barColor[end] = startColorB;
            A.Update();
            A.sleep(A.animSpeed);

            for (int i = start; i <= end; i++)
            {
                if (!A.isSorting){
                    return;
                }
                if (p > mid)
                    Arr[k++] = A.getValue(q++);

                else if (q > end)
                    Arr[k++] = A.getValue(p++);

                else if (A.getValue(p) < A.getValue(q))
                    Arr[k++] = A.getValue(p++);

                else
                    Arr[k++] = A.getValue(q++);
            }
            for (int i = 0; i < k; i++)
            {
                if (!A.isSorting){
                    return;
                }
                A.barColor[start] = A.purpleColor;
                A.Update();
                A.sleep(A.animSpeed);
                A.increaseComparison();
                A.setValue(start++, Arr[i]);
                if  (start-1 != r && start-1!= s)
                    A.barColor[start-1] = A.orangeColor;

                A.Update();

                if  (start-1 != r && start-1!= s)
                    A.sleep(A.animSpeed);

                if  (start-1 == r)
                {
                    A.barColor[r] = A.blueColor;
                    A.sleep(A.animSpeed);
                }
                else if (start-1 == s)
                {
                    A.barColor[s] = A.pinkColor;
                    A.sleep(A.animSpeed);
                }

            }
        }
        public void mergesort(SortArray arr,int start,int end){
            arr.barColor[start] = Color.red;
            arr.barColor[end] = Color.red;

            arr.Update();
            arr.sleep(arr.animSpeed);

            arr.barColor[start] = arr.blueColor;
            arr.barColor[end] = arr.pinkColor;

            if (start == end){
                arr.barColor[start] = new Color(9, 132, 227);
            }
            arr.Update();
            arr.sleep(arr.animSpeed);
            if(start<end){
                if (!arr.isSorting){
                    return;
                }
                int mid=(start+end)/2;
                mergesort(arr,start,mid);
                mergesort(arr,mid+1,end);
                mergee(arr,start,mid,end);

                arr.Update();
            }
        }
        public void sortdeMerge(SortArray arr){
            arr.isSorting = true;
            arr.comparisons = 0;

            mergesort(arr, 0, arr.arrSize-1);

            arr.sortAnim();
        }
    }

